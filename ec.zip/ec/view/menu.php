<?php //menu_.php



        //split the current dir path to array                                
        $menumodel_path = explode(DIRECTORY_SEPARATOR,__DIR__);         
        //build path to menu folder
        $pom=count($menumodel_path)-1;
        array_splice($menumodel_path,$pom,count($menumodel_path),array("model","menu","menu_model.php"));
        $path = implode(DIRECTORY_SEPARATOR, $menumodel_path);  

        //load menu model.php - the menu builder class
        require_once $path;
        $menubuilder = new MenuBuilder();
        $menuarray = $menubuilder->readmenufromdir();

        
?>

        <nav id="nav">
           <div class="innertube">
                <h3><p class="three">Concrete EN 1992-1-1</h3></p>
                <ul>
<?php                     
        //output menu
        foreach ($menuarray as $key => $value){
            echo'<li><p class="two"><a href='.$value.'>'.$key.'</a></p></li>';
        }
                    		
                '</ul>';
        
        //check how deep is "ec" dir
        $how_deep_ec_is= array_search('ec', explode(DIRECTORY_SEPARATOR,__DIR__)); 
        $fromWhereIsCalled=filter_input(INPUT_SERVER, 'SCRIPT_NAME', FILTER_SANITIZE_STRING);
        
        //netbeans
        $fromWhereIsCalled_count=count(explode(DIRECTORY_SEPARATOR,$fromWhereIsCalled))-2;
        
        //www
        //$fromWhereIsCalled_count=count(explode(DIRECTORY_SEPARATOR,$fromWhereIsCalled))-1;
        
        //TEST
        //echo $how_deep_ec_is;
        // echo '<br>';
        //echo $fromWhereIsCalled_count;
        
        if($how_deep_ec_is-$fromWhereIsCalled_count==3){
            echo        '<h3><p class="three"><a href="index.php">Home</a></h3></p>';
        }
        elseif($how_deep_ec_is-$fromWhereIsCalled_count==2){
            echo        '<h3><p class="three"><a href="../index.php">Home</a></h3></p>';
        }
        elseif($how_deep_ec_is-$fromWhereIsCalled_count==1){
            echo        '<h3><p class="three"><a href="../../index.php">Home</a></h3></p>';    
        }       
?>        
        </div>
        </nav>





