<?php //footer.php
echo <<<_END

 <footer>
  <p>

  email: <a href="mailto:kisbo.000webhost@gmail.com"> kisbo.000webhost@gmail.com </a>.<br>
  2018
    </p>
  
  
  
</footer> 

_END;

?>

