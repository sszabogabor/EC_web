<?php

class CommonView {
    
    public function userFriendlyOption($name, $size, $arraydata, $postdata, $preferredval)
    //$name string - option name
    //$size int - option size
    //$$arrvalues array associative - key => value .... value => display
    //$postdata - data from $_POST  
    //$preferred value
    {
   
        $tempvar = '<select name=' . $name .  ' size=' . $size . '>';
        $myarray = array ($tempvar);
         
        if ($postdata != 'false_'){
            foreach($arraydata as $x => $x_value) {
                if ($postdata==$x){
                            $tempvar = '<option value=' . $x . ' selected>' . $x_value . '</option>';
                            array_push($myarray, $tempvar);                             
                }
                else{
                            $tempvar = '<option value=' . $x . '>' . $x_value . '</option>';
                            array_push($myarray, $tempvar);
                }
            }
            $tempvar = '</select><br><br>';
            array_push($myarray, $tempvar);
            
        }else{
            foreach($arraydata as $x => $x_value) {
                if ($preferredval==$x){
                            $tempvar = '<option value=' . $x . ' selected>' . $x_value . '</option>';
                            array_push($myarray, $tempvar);  
                }
                else{
                            $tempvar = '<option value=' . $x . '>' . $x_value . '</option>';
                            array_push($myarray, $tempvar);  
                }
            }
            $tempvar = '</select><br><br>';
            array_push($myarray, $tempvar);
        }
        return $myarray;
    }

    public function userFriendlyTextBox($name, $size, $value, $postdata)
    //$name string - textbox name
    //$size int - textbox size
    //$$values
    //$postdata - data from $_POST  
    {   
        $tempvar = '<input type="text" name="'. $name .'" size= "'. $size .'" value= ';
   
        if ($postdata != 'false_'){
                    $tempvar = $tempvar . $postdata;        
        }
        else{
                    $tempvar = $tempvar. $value;           
        }    
        $tempvar = $tempvar.'><br>';
        return $tempvar;
    }
    
    
    public function userFriendlyBtnGroup($name, $size, $arraydata, $postdata, $preferredval)
    //$name string - option name
    //$size int - option size
    //$$arrvalues array associative - key => value .... value => display
    //$postdata - data from $_POST  
    //$preferred value
    {

        
        
        
    }
}

?>
