<?php //head.php

echo <<<_END
<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<title>EC</title>
		<link rel="stylesheet"  type="text/css"  href="../ECstyle.css"/>

</head>

_END;


?>

