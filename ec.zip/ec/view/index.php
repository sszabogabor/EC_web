<!DOCTYPE html>
<html>
    <head>
            <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
            <title>EC</title>
            <link rel="stylesheet"  type="text/css"  href="ECstyle.css"/>

    </head>

    <body>

<!--?php include_once 'header.php';?-->
			
        <main>
            <div class="innertube">

                <h1>EC</h1>
                <p class="one">This site provides tools to cover basic calculations according to Eurocodes. Check the content and feel free to use it on your own responsibility.</p>

            </div>
        </main>
        <?php	
        include_once 'menu.php';
        include_once 'footer.php';
        ?>
    </body>
</html>
