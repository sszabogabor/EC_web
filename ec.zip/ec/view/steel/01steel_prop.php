<?php	//steel_prop.php //menuitemname>Tab.3.1; steel properties 

//get the model
//search for model file
$dir=__DIR__;
//split the current dir path to array         

$current_path = explode(DIRECTORY_SEPARATOR,__DIR__);

$pom=count($current_path)-2;

//build path to model folder
$model_path=$current_path;
array_splice($model_path,$pom,count($model_path),array("model","concrete","common_model.php"));
$model_path_string = implode(DIRECTORY_SEPARATOR, $model_path);
include_once $model_path_string;

echo <<<_END
<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<title>EC</title>
		<link rel="stylesheet"  type="text/css"  href="ECstyle.css"/>
		
	</head>
	
	<body> 	
	<div class="container">
				
		<main>
			<div class="innertube">
				
				<h1>Strength characteristics for concrete; EN 1992-1-1,Table 3.1 </h1>
				<p class="one">[MPa] <p>
_END;

//TABLE 1
echo '<table style="width:100%">';
//echo '<tr><th> Concrete </th><th> fck </th><th> fck,cube </th><th> fcm </th><th> fctm </th><th> fctk,0.05 </th><th> fctk,0.95 </th><th>Ecm</th></tr>';

$model = new CommonConcreteModel();
$concreteprops = $model->read_concrete_props_data();


for($i=0;$i<count($concreteprops);++$i){
    for($j=0;$j<count($concreteprops[$i]);++$j){

	echo '<th>' . $concreteprops[$i][$j]  . '</th>';
	
    }
    echo  '<tr>';
}

echo '</table>';



echo '</div>';
echo '</main>';

//build path to view folder
$view_path=$current_path;
array_splice($view_path,$pom,count($view_path),array("view"));
$view_path_string = implode(DIRECTORY_SEPARATOR, $view_path);


include_once $view_path_string.DIRECTORY_SEPARATOR.'menu.php';
include_once $view_path_string.DIRECTORY_SEPARATOR.'footer.php';

echo '</div>';
echo '</body>';
echo '</html>';

?>	