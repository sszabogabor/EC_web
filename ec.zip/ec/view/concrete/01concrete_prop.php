<?php	//concrete_prop.php //menuitemname>Tab.3.1; strength char. for concrete 

//get the model
//split the current dir path to array         
$current_path = explode(DIRECTORY_SEPARATOR,__DIR__);

$current_path_count_2less=count($current_path)-2;

//build path to model folder
$model_path=$current_path;
array_splice($model_path,$current_path_count_2less,count($model_path),array("model","concrete","common_model.php"));
$model_path_string = implode(DIRECTORY_SEPARATOR, $model_path);
include_once $model_path_string;

//build path to view folder root
$view_path=$current_path;
array_splice($view_path,$current_path_count_2less,count($view_path),array("view"));
$view_path_string = implode(DIRECTORY_SEPARATOR, $view_path);
?>


<!DOCTYPE html>
<html>
    <?php include_once $view_path_string.DIRECTORY_SEPARATOR.'head.php'; ?>
	
	<body> 	
                <div class="container">

                        <main>
                                <div class="innertube">

                                        <h1>Strength characteristics for concrete</h1>
                                        <h3>EN 1992-1-1:2004,Table 3.1 </h3>
                                        
                                        <!--TABLE 1-->
                                        <table style="width:100%">
                                            <?php
                                                //echo '<tr><th> Concrete </th><th> fck </th><th> fck,cube </th><th> fcm </th><th> fctm </th><th> fctk,0.05 </th><th> fctk,0.95 </th><th>Ecm</th></tr>';

                                            $model = new CommonConcreteModel();
                                            $concreteprops = $model->read_concrete_props_data();


                                            for($i=0;$i<count($concreteprops);++$i){
                                                for($j=0;$j<count($concreteprops[$i]);++$j){

                                                    //greece letters workaround
                                                    //find if there is "eps"
                                                    $pos=strpos($concreteprops[$i][$j],'eps');
                                                    if($pos===FALSE){
                                                        echo '<th>' . $concreteprops[$i][$j]  . '</th>';
                                                    }
                                                    //if there is 'eps' send to function conv_to_greece to convert it to greece letter
                                                    else{
                                                        //echo '<th>' . '&epsilon;' . substr($concreteprops[$i][$j],3). '</th>';
                                                        echo '<th>' . $model->conv_to_greece($concreteprops[$i][$j], 'eps'). '</th>';
                                                    }

                                                }
                                                echo  '<tr>';
                                            }
                                            ?>

                                        </table>
                                </div>
                        </main>

                    <?php
                    //inclulde footer,menu
                    include_once $view_path_string.DIRECTORY_SEPARATOR.'menu.php';
                    include_once $view_path_string.DIRECTORY_SEPARATOR.'footer.php';
                    ?>

                </div>
        </body>
</html>

?>	