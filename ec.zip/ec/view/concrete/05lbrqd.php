<?php   //05lbrqd.php //menuitemname>8.4.3; lb,rqd 

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

//get the model and read data from file
//split the current dir path to array         
$current_path = explode(DIRECTORY_SEPARATOR,__DIR__);
//for root
$current_path_count_2less=count($current_path)-2;
//for view
$current_path_count_1less=count($current_path)-1;

//build path to model folder
$model_path=$current_path;
array_splice($model_path,$current_path_count_2less,count($model_path),array("model","concrete","common_model.php"));
$model_path_string = implode(DIRECTORY_SEPARATOR, $model_path);
include_once $model_path_string;

//build path to controller folder
$controller_path=$current_path;
array_splice($controller_path,$current_path_count_2less,count($controller_path),array("controller","concrete","lbrqd_controller.php"));
$controller_path_string = implode(DIRECTORY_SEPARATOR, $controller_path);
include_once $controller_path_string;

//build path to common view file
$view_path=$current_path;
array_splice($view_path,$current_path_count_1less,count($view_path),array("common_view.php"));
$view_path_string_common_view = implode(DIRECTORY_SEPARATOR, $view_path);
include_once $view_path_string_common_view;

//build path to view folder root
array_splice($view_path,$current_path_count_2less,count($view_path),array("view"));
$view_path_string = implode(DIRECTORY_SEPARATOR, $view_path);

//
$model = new CommonConcreteModel();

$controller = new LbrqdController();
//get data from controller
$controller_return_values = $controller->lbrqd();

$view = new CommonView();
?>


<!DOCTYPE html>
<html>
    <?php include_once $view_path_string.DIRECTORY_SEPARATOR.'head.php'; ?>
	
	<body> 	
                <div class="container">

                        <main>
                                <div class="innertube">

                                        <h1>Basic anchorage length, l<sub>b,rqd</sub></h1>
                                        
                                        <p class="one">Either use design stress σ<sub>sd</sub> or choose yield strength of the bar f<sub>yk</sub>. <p>
                                        <p class="one">Used partial factors &gamma;<sub>c</sub> = 1.5, &gamma;<sub>s</sub> = 1.15 (for f<sub>yk</sub>).<p>

                                        <form method="post" action="05lbrqd.php"> 
                                        
                                        <p class="three">Enter σ<sub>sd</sub> [MPa]

                                        <input type="text" name="sd" size="5" value=0>
                                        or select bar steel grade from list and use nominal yield stress for anchorage length calculation -> 
                                        <?php //build the combobox
                                        $arr = array ('400'=>'400', '500'=>'500', '600'=>'600');
                                        $returnarray = $view->userFriendlyOption('fyk_sel','1',$arr, (isset($_POST['fyk_sel']) ? ($_POST['fyk_sel']) : 'false_'),"500");
                                        foreach($returnarray as $myecho) {
                                            echo $myecho;    
                                        }
                                        ?>
                                        Bond conditions: good <input type="radio" style="style = margin: 0px" name="bond_co" value="1" <?php echo (isset($_POST['bond_co']) && $_POST['bond_co']==1) ? 'checked="checked"' : ''; ?> >
									other cases <input type="radio" name="bond_co" value="0.7" <?php echo (isset($_POST['bond_co']) && $_POST['bond_co']==0.7) ? 'checked="checked"' : ''; ?> > <br><br>
                                        <input type="submit" value="Recalc"><br><br>
                                        <?php
                                        //output
                                        if ($controller_return_values!=FALSE){
                                            echo 'Design stress fyd: ' . round($controller_return_values[0],1) . ' [MPa] <br>';
                                            echo 'Bond conditions: η2= ' .$controller_return_values[1]. ' for fbd calculation <br>';
                                            
                                            //TABLE
                                            echo '<table style="width:100%">';
                                            //TABLE FIRST ROW - CONCRETES
                                            echo '<tr>';		
                                            echo '<th> Concrete </th>';	
                                            for ($j=1;$j<count($controller_return_values[2]);++$j){
                                                echo '<th>'  . $controller_return_values[2][$j] . '</th>' ; 
                                            }
                                            echo'</tr>';
                                            
                                            //TABLE second ROW - CONCRETES fctk
                                            echo '<tr>';		
                                            echo '<th> fctk 0.05 [MPa]</th>';			
                                            for ($j=1;$j<count($controller_return_values[3]);++$j){
                                                echo '<th>'  . $controller_return_values[3][$j] . '</th>' ; 
                                            }
                                            echo'</tr>';
                                            
                                            //TABLE THIRD ROW - CONCRETES fbd
                                            echo '<tr>';		
                                            //echo '<th> fbd [MPa]</th>';
                                            echo '<th title="Values are valid for reinforcement diameters <=32mm, for diamters >32mm values for fbd is calcualted with ni2=(132-fi)/100 "> fbd [MPa]</th>'; 
                                            
                                            for ($j=1;$j<count($controller_return_values[4]);++$j){
                                                echo '<th>'  . $controller_return_values[4][$j] . '</th>' ; 
                                            }
                                            echo'</tr>';
                                            
                                            //TABLE emprt ROW - BAR DIAMETERS
                                            echo '<tr>';
                                            echo '<th> Bar diameter [mm] </th>';
                                            // *************MANUAL INPUT table size for merged cells 14
                                            echo '<th colspan="14"> l<sub>b,rqd</sub> [mm] </th>';
                                            echo'</tr>';
                                            
                                            //TABLE lb rqd
                                            $temp=count($controller_return_values[5]);
                                            for ($j=1;$j<count($controller_return_values[5]);++$j){
                                                echo '<tr>';
                                                $temp=count($controller_return_values[5][$j]);
                                                for ($l=0;$l<count($controller_return_values[5][$j]);++$l){
                                                    echo '<th>'  . $controller_return_values[5][$j][$l] . '</th>' ;
                                                }
                                                echo '</tr>';
                                            }
                                            echo '</table>';
                                        }
                                        else {
                                            echo "Input is not valid";
                                        }
                                        ?>
                                        <p>
                                </div>
                        </main>

                    <?php
                    
                    //include menu, footer

                    include_once $view_path_string.DIRECTORY_SEPARATOR.'menu.php';
                    include_once $view_path_string.DIRECTORY_SEPARATOR.'footer.php';
                    ?>

                </div>
        </body>
</html>

?>
