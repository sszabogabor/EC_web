<?php     //bars_prop.php //menuitemname>reinforcing bars area table
//get the model and read data from file
//split the current dir path to array         
$current_path = explode(DIRECTORY_SEPARATOR,__DIR__);
$current_path_count_2less=count($current_path)-2;

//build path to model folder
$model_path=$current_path;
array_splice($model_path,$current_path_count_2less,count($model_path),array("model","concrete","common_model.php"));
$model_path_string = implode(DIRECTORY_SEPARATOR, $model_path);
include_once $model_path_string;

//build path to view folder root
$view_path=$current_path;
array_splice($view_path,$current_path_count_2less,count($view_path),array("view"));
$view_path_string = implode(DIRECTORY_SEPARATOR, $view_path);


$model = new CommonConcreteModel();
$rebarprops = $model->read_rebar_data();
?>

<!DOCTYPE html>
<html>
    <?php include_once $view_path_string.DIRECTORY_SEPARATOR.'head.php'; ?>
	
	<body> 	
                <div class="container">	
				
		<main>
			<div class="innertube">
				
				<h1>Reinforcing bars cross section area table</h1>
				<p class="one">Bars cross section area Ast [mm2]<p>


                        <!--TABLE 1-->
                        <table style="width:100%">
                        <!--TABLE  HEADER-->

                        <tr><th> Weight[kg/m] </th><th> Bars </th>
                        <?php
                        for($n=1;$n!=10;++$n){
                                echo '<th>'. $n . '</th>';
                        }		
                        echo '</tr>';	

                        //$rebarprops[$i][0] fi
                        //$rebarprops[$i][1] kg
                        //$rebarprops[$i][2] mm2
                        //TABLE

                        for($i=0;$i<count($rebarprops);++$i) {
                            echo '<tr>';
                                //print weight and bar diameter
                            if(strncmp($rebarprops[$i][0],"f",1)){
                                        echo '<th>'  .$rebarprops[$i][1].'</th><th>'. $rebarprops[$i][0] . '</th>' ; 
                                }
                                else{
                                        echo '<th>'  .$rebarprops[$i][1].'</th><th>'. substr($rebarprops[$i][0],2) . '</th>' ; 
                                }
                                //pritn areas * count
                                //rebarprops are str have to conv to float
                                for($n=1;$n!=10;++$n){
                                        echo '<th title="400.Ast.fy/1.15= ' . round(0.4*floatval($rebarprops[$i][2])*$n/1.15,1) . ' kN
500.Ast.fy/1.15= ' . round(0.5*floatval($rebarprops[$i][2])*$n/1.15,1) . ' kN
600.Ast.fy/1.15= ' . round(0.6*floatval($rebarprops[$i][2])*$n/1.15,1) . ' kN "  >'  . floatval($rebarprops[$i][2])*$n . '</th>' ; 
                                }
                                echo'</tr>';
                        }

                        echo '</table>';

                        //TABLE 2
                        echo 
                        '<p class="one">Bars cross section area Ast by spacing [mm2/m]<p>';
                        echo '<table>';
                        //TABLE HEADER
                        echo '<tr><th> Spacing [mm]/Bars  </th>' ;
                        for($i=0;$i<count($rebarprops);++$i) {
                                //print bar diameters
                            if(strncmp($rebarprops[$i][0],"f",1)){
                                        echo '<th>'  . $rebarprops[$i][0] . '</th>' ; 
                                }
                                else{
                                        echo '<th>'. substr($rebarprops[$i][0],2) . '</th>' ; 
                                }
                            }		
                        echo '</tr>';	

                        //TABLE
                        for($n=50; $n<251; $n=$n+5){
                                echo '<tr>';
                                echo '<th>'  . $n . '</th>';
                                for($i=0;$i<count($rebarprops);++$i) {
                                        echo '<th>'  . round(floatval($rebarprops[$i][2])*(1000/$n),0) . '</th>' ; 
                                };
                                echo '</tr>';
                        };

                        echo '<tr>';
                        echo '<th>' . 300 . '</th>';
                                for($i=0;$i<count($rebarprops);++$i) {
                                        echo '<th>'  . round(floatval($rebarprops[$i][2])*(1000/300),0) . '</th>' ; 
                                };
                        echo '</tr>';

                        echo '<tr>';
                        echo '<th>' . 350 . '</th>';
                                for($i=0;$i<count($rebarprops);++$i) {
                                        echo '<th>'  . round(floatval($rebarprops[$i][2])*(1000/350),0) . '</th>' ; 
                                };
                                
                         echo '</tr>';
                         
                         //TABLE HEADER AT THE BOTTOM
                        echo '<tr><th> Spacing [mm]/Bars  </th>' ;
                        for($i=0;$i<count($rebarprops);++$i) {
                                //print bar diameters
                            if(strncmp($rebarprops[$i][0],"f",1)){
                                        echo '<th>'  . $rebarprops[$i][0] . '</th>' ; 
                                }
                                else{
                                        echo '<th>'. substr($rebarprops[$i][0],2) . '</th>' ; 
                                }
                            }		
                        echo '</tr>';	                         
                         
                        ?>
                        
                        </table>


                        </div>
                </main>

                <?php
                //include footer, menu


                include_once $view_path_string.DIRECTORY_SEPARATOR.'menu.php';
                include_once $view_path_string.DIRECTORY_SEPARATOR.'footer.php';
                ?>

                </div>
        </body>
</html>

<?php
//array to push for asociative array
function array_push_assoc($array, $key, $value){
	$array[$key] = $value;
return $array;
}

function sanitizeString($var){
	$var=stripslashes($var);
	$var=strip_tags($var);
	$var=htmlentities($var);
	return $var;
}

?>