<?php     //bar_tension.php //menuitemname>3.2; bar in tension  

//get the model and read data from file
//split the current dir path to array         
$current_path = explode(DIRECTORY_SEPARATOR,__DIR__);
//for root
$current_path_count_2less=count($current_path)-2;
//for view
$current_path_count_1less=count($current_path)-1;

//build path to model folder
$model_path=$current_path;
array_splice($model_path,$current_path_count_2less,count($model_path),array("model","concrete","common_model.php"));
$model_path_string = implode(DIRECTORY_SEPARATOR, $model_path);
include_once $model_path_string;

//build path to controller folder
$controller_path=$current_path;
array_splice($controller_path,$current_path_count_2less,count($controller_path),array("controller","concrete","bar_tension_controller.php"));
$controller_path_string = implode(DIRECTORY_SEPARATOR, $controller_path);
include_once $controller_path_string;

//build path to common view file
$view_path=$current_path;
array_splice($view_path,$current_path_count_1less,count($view_path),array("common_view.php"));
$view_path_string_common_view = implode(DIRECTORY_SEPARATOR, $view_path);
include_once $view_path_string_common_view;

//build path to view folder root
array_splice($view_path,$current_path_count_2less,count($view_path),array("view"));
$view_path_string = implode(DIRECTORY_SEPARATOR, $view_path);

//
$model = new CommonConcreteModel();
$rebarprops = $model->read_rebar_data();

$controller = new BarTensionController();
//get data from controller
$controller_return_values = $controller->bar_tension();

$view = new CommonView();


?>

<!DOCTYPE html>
<html>
    
    <?php include_once $view_path_string.DIRECTORY_SEPARATOR.'head.php'; ?>
	
	<body> 	
	<div class="container">
				
		<main>
			<div class="innertube">
				
				<h1>Bar tension resistance</h1>
				<p class="one">Either enter or choose yield strength of the bar fyk. <p>
                                <p class="one" data-toggle="tooltip" title="EN 1992-1-1:2004,Table 2.1N" >Used partial factor for steel &gamma;s = 1.15.<p>
				
				<form method="post" action="02bar_tension.php"> 
                                
				<p class="three">
				Enter fyk [MPa]
                                
				<input type="text" name="fyk" size="5" value=0>
				or select bar steel grade from list ->
                                
                                <!--form>
                                 <input type="radio" name="fyk_sel" value="400"> 400
                                 <input type="radio" name="fyk_sel" value="500" checked> 500
                                 <input type="radio" name="fyk_sel" value="600"> 600
                                </form--> 
                                
                                
                                <?php //build the combobox
                                $arr = array ('400'=>'400', '500'=>'500', '600'=>'600');
                                $returnarray = $view->userFriendlyOption('fyk_sel','1',$arr, (isset($_POST['fyk_sel']) ? ($_POST['fyk_sel']) : 'false_'),"500");
                                foreach($returnarray as $myecho) {
                                    echo $myecho;    
                                }
                                ?>
 
				Bar diameter:   <select name="fi" size="1">
<?php                   //fill the combobox with bars diameter
			for ($i=0; $i<count($rebarprops);++$i)	{
				if (isset($_POST['fi']) && $_POST['fi']==$rebarprops[$i][0]){
					echo '<option value=' . $rebarprops[$i][0] . ' selected>' . $rebarprops[$i][0] . ' </option>';
				}
				else{

                                    echo '<option value=' . $rebarprops[$i][0] . '>' . $rebarprops[$i][0] . ' </option>';
				}
			}
					
                        echo '</select><br>';
                        echo 'Number of bars: <input type="text" name="num_bar" size="5" value=' . (isset($_POST['num_bar']) ?  $_POST['num_bar'] : '1') . '></p>';
                        echo '<input type="submit" value="Calculate"><br></p>';

                        

                        //output
                        if ($controller_return_values!=FALSE){
                            echo '<p class="three">fyd: ' . round($controller_return_values['fyk']/1.15,0) . ' [MPa] <br>';
                            echo 'Bar diameter: ' . $controller_return_values['fi'] . ' mm <br>';
                            echo 'Number of bars: ' . $controller_return_values['num_bar'] . ' <br>';
                            echo '1 bar area: ' . $controller_return_values['ast'] . ' mm2 <br>';
                            echo 'Resistance in tension: ' . number_format($controller_return_values['Rd'],1,'.','') . ' kN </p> <br>';
                        }
                        
?>
</div>
</main>
<?php
                    //include menu, footer
                    include_once $view_path_string.DIRECTORY_SEPARATOR.'menu.php';
                    include_once $view_path_string.DIRECTORY_SEPARATOR.'footer.php';
?>

</div>
</body>
</html>

