<?php     //08min_max_reinforcement_areas.php ////menuitemname>9.2.1.1; min. and max. reinforcement areas 

//get the model and read data from file
//split the current dir path to array         
$current_path = explode(DIRECTORY_SEPARATOR,__DIR__);
//for root
$current_path_count_2less=count($current_path)-2;
//for view
$current_path_count_1less=count($current_path)-1;

//build path to model folder
$model_path=$current_path;
array_splice($model_path,$current_path_count_2less,count($model_path),array("model","concrete","common_model.php"));
$model_path_string = implode(DIRECTORY_SEPARATOR, $model_path);
include_once $model_path_string;

//build path to controller folder
$controller_path=$current_path;
array_splice($controller_path,$current_path_count_2less,count($controller_path),array("controller","concrete","min_max_reinforcement_areas_controller.php"));
$controller_path_string = implode(DIRECTORY_SEPARATOR, $controller_path);
include_once $controller_path_string;

//build path to common view file
$view_path=$current_path;
array_splice($view_path,$current_path_count_1less,count($view_path),array("common_view.php"));
$view_path_string_common_view = implode(DIRECTORY_SEPARATOR, $view_path);
include_once $view_path_string_common_view;

//build path to view folder root
array_splice($view_path,$current_path_count_2less,count($view_path),array("view"));
$view_path_string = implode(DIRECTORY_SEPARATOR, $view_path);

$model = new CommonConcreteModel();
$rebarprops = $model->read_rebar_data();
$concreteprops = $model->read_concrete_props_data();

$controller = new MinMaxReinfAreasController();
//get data from controller
$controller_return_values = $controller->min_max_reinf_areas();

$view = new CommonView();
?>


<!DOCTYPE html>
<html>
    <?php include_once $view_path_string.DIRECTORY_SEPARATOR.'head.php'; ?>
	
	<body> 	
	<div class="container">	
				
		<main>
			<div class="innertube">
				
				<h1>Minimum and maximum reinforcement areas</h1>
				
				
				<form method="post" action="08min_max_reinforcement_areas.php">
				<p class="three">

<?php

// get data from concreteprops array and fill the array $concretePropArray_Concr for combobox usage
for($i=2;$i<count($concreteprops);++$i){
    $concretePropArray_Concr[$i-2] = "C".$concreteprops[$i][0]. "/" .$concreteprops[$i][1] ;
}
echo 'Selected concrete strength class ';
$returnarray = $view->userFriendlyOption('Concrete','1',$concretePropArray_Concr, (isset($_POST['Concrete']) ? ($_POST['Concrete']) : 'false_'),'none');
foreach($returnarray as $myecho) {
    echo $myecho;    
}

echo 'Reinforcement type [fyk] ';
$temparray = array ('400'=>'400', '500'=>'500', '600'=>'600');
$returnarray = $view->userFriendlyOption('fyk','1',$temparray, (isset($_POST['fyk']) ? ($_POST['fyk']) : 'false_'),'500');
foreach($returnarray as $myecho) {
    echo $myecho;    
}

echo 'Bar diameter [mm] ';
$temparray = array (8=>8, 10=>10, 12=>12, 14=>14, 16=>16, 20=>20, 22=>22, 25=>25, 28=>28, 32=>32);
$returnarray = $view->userFriendlyOption('Bar','1',$temparray, (isset($_POST['Bar']) ? ($_POST['Bar']) : 'false_'),'none');
foreach($returnarray as $myecho) {
    echo $myecho;    
}

echo 'Number of bars ';
echo $view->userFriendlyTextBox("n", "5", "5", (isset($_POST['n']) ? ($_POST['n']) : 'false_'));

echo 'Section height [mm] ';
echo $view->userFriendlyTextBox('h', '5', '200', (isset($_POST['h']) ? ($_POST['h']) : 'false_'));

echo 'Section width [mm] ';
echo $view->userFriendlyTextBox('b', '5', '350', (isset($_POST['b']) ? ($_POST['b']) : 'false_'));

echo 'Cover [mm]  ';
echo $view->userFriendlyTextBox('c', '5', '20', (isset($_POST['c']) ? ($_POST['c']) : 'false_'));

echo '<input type="submit" value="Calculate"><br></p>';

echo '<p class="one">';

//output
if ($controller_return_values!=FALSE){
echo 'Effective depth of a cross-section d: ' . $controller_return_values['d'] . '  [mm]<br>';
echo 'fck: ' . $controller_return_values['fck'] . ' [MPa] <br>';
echo 'fctm: ' . $controller_return_values['fctm'] . ' [MPa] <br>';
echo 'fyk: ' . $controller_return_values['fyk'] . ' [MPa] <br>';
echo 'Ast= ' . $controller_return_values['ast'] . ' [mm2] <br>';
echo 'Ast,min= ' . $controller_return_values['astmin'] . ' [mm2]  >>> ' . round(($controller_return_values['astmin']/$controller_return_values['ast'])*100,1) . '% <br>';
echo 'Ast,max= ' . $controller_return_values['astmax'] . ' [mm2]  >>> ' . round(($controller_return_values['ast']/$controller_return_values['astmax'])*100,1) . '% <br>';
}


?>
</div>
</main>
<?php
                    //include menu, footer
                    include_once $view_path_string.DIRECTORY_SEPARATOR.'menu.php';
                    include_once $view_path_string.DIRECTORY_SEPARATOR.'footer.php';
?>

</div>
</body>
</html>

<?php
    function sanitizeString($var){
	$var=stripslashes($var);
	$var=strip_tags($var);
	$var=htmlentities($var);
	return $var;
    }
  ?>