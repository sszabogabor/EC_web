<?php //header.php
echo <<<_END

  <header>
    <h1>EC</h1>
    <p>Eurocodes</p>
  </header> 

_END;

?>