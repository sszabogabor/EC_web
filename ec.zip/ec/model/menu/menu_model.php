<?php  //menu_model.php

//read file structure from view dir
//read menuitem name from view files
//return array with hrefs and names

class MenuBuilder {
    public function readmenufromdir(){
        
                //find the view folder and read data from files
                //
		//split the current dir path to array                                
		$menumodel_path = explode(DIRECTORY_SEPARATOR,__DIR__);
                //check how deep is "ec" dir
                $how_deep_ec_is= array_search('ec', $menumodel_path);            
		//build path to view folder
		$pom=count($menumodel_path)-2;
		array_splice($menumodel_path,$pom,count($menumodel_path),array("view","concrete"));
                $path = implode(DIRECTORY_SEPARATOR, $menumodel_path);  
		
		//get the directory content
		$files1=scandir($path);
		
		//get rid of . .. and filenames startswith _
                //remove first 2 element
                array_splice($files1, 0, 2);

                //remove files startswith _
                for ($i=0;$i<count($files1);$i++){
                    foreach ($files1 as &$value) {
                        if (substr($value, 0,1)=='_'){
                            array_splice($files1, 0, 1);
                            break; 
                        }
                    }
                }
		

                //array for return
                //first item is temporary and will be removed
                $array_result=array("nomenuname"=>"nopath");
                //build array with menu nameand path - the return value of function
		foreach ($files1 as &$value) {
                    //output check
                    //echo  $value;
                    //echo '<br>';
                    
                    $path_to_view=$path.DIRECTORY_SEPARATOR.$value;
                    
			
                    $myfile = fopen($path_to_view, "r") or die("Unable to open file!");
                    $line = fgets($myfile);
                    //echo $line;
                    fclose($myfile);
                    
                    //extract view name from line
                    $menutext=substr($line,strpos($line,">")+1);
                    
                    //get the path to file without system directories
                    //extract view path from path
                    $temp = explode(DIRECTORY_SEPARATOR,$path_to_view);
                    //remove selected dir from top to get the rest what is used in webserver-we works in view so it is the target
                    //
                    //
                    //$_SERVER['SCRIPT_NAME']
                    $fromWhereIsCalled=filter_input(INPUT_SERVER, 'SCRIPT_NAME', FILTER_SANITIZE_STRING);
                    $fromWhereIsCalled_count=count(explode(DIRECTORY_SEPARATOR,$fromWhereIsCalled))-2;
                    
                    
                    
                    array_splice($temp,0,$how_deep_ec_is+$fromWhereIsCalled_count);
                    
                    
                    $relative_path_to_view = implode(DIRECTORY_SEPARATOR, $temp);
                    //$full_path_to_view = $_SERVER['SERVER_NAME'].'/ec/' . implode(DIRECTORY_SEPARATOR, $temp);

                    $array_result  = array_merge($array_result,array($menutext => $relative_path_to_view));
                    
                    //$array_result = $temp_array;
                    
		}

                //get rid of first temp item
                //remove first item
                array_splice($array_result, 0, 1);
	
    return $array_result;
    }
    
}

//$cc = new MenuBuilder();
//$cc->readmenufromdir();

?>
