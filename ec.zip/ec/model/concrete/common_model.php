<?php   //common_model.php

class CommonConcreteModel{
    public function read_concrete_props_data(){
        //READ REBAR DATA FROM FILE
                
        //search for data file
        //split the current dir path to array                                
	$model_path = explode(DIRECTORY_SEPARATOR,__DIR__);
   
        //build path to data folder
        $pom=count($model_path)-2;
        array_splice($model_path,$pom,count($model_path),array("data","concrete","dat_1992_1_1_Tab3_1.txt"));
        $path = implode(DIRECTORY_SEPARATOR, $model_path); 
        
        $fh = fopen($path,'r') or die ("Concrete properties read error");
        $concrete_props= array();
        if ($fh){
            while (($line=fgets($fh)) !== false){
                $temp_arr=str_getcsv($line,";");
                //FILL ARRAYS WITH BAR PROPERTIES DIAMETER, AREA, WEIGHT
                array_push($concrete_props,$temp_arr);
                
            }
            fclose($fh);
        }
    return $concrete_props;    
    }
    
    public function read_rebar_data(){
        //READ REBAR DATA FROM FILE
        
        //search for data file
        //split the current dir path to array                                
	$model_path = explode(DIRECTORY_SEPARATOR,__DIR__);
        //build path to data folder
        $pom=count($model_path)-2;
        array_splice($model_path,$pom,count($model_path),array("data","concrete","dat_rebar.txt"));
        $path = implode(DIRECTORY_SEPARATOR, $model_path); 
        
        $rebarbar_data= array();
        
        $fh = fopen($path,'r') or die ("Rebar data read error");
        if ($fh){
            while (($line=fgets($fh)) !== false){
                $temp_arr=str_getcsv($line,";");
                //FILL ARRAYS WITH BAR PROPERTIES DIAMETER, AREA, WEIGHT
                array_push($rebarbar_data,$temp_arr);
                
            }
            fclose($fh);
        }

        return $rebarbar_data;
    
    }
    
    public function read_data($path_to_datafile_startswith_data_folder){
        //READ DATA FROM FILE ; separated
        
        //search for data file
        //split the current dir path to array                                
	$model_path = explode(DIRECTORY_SEPARATOR,__DIR__);
        //build path to data folder
        $pom=count($model_path)-2;
        array_splice($model_path,$pom,count($model_path),array($path_to_datafile_startswith_data_folder));
        $path = implode(DIRECTORY_SEPARATOR, $model_path); 
        
        $data= array();
        
        $fh = fopen($path,'r') or die ("Rebar data read error");
        if ($fh){
            while (($line=fgets($fh)) !== false){
                $temp_arr=str_getcsv($line,";");
                //FILL ARRAYS WITH BAR PROPERTIES DIAMETER, AREA, WEIGHT
                array_push($data,$temp_arr);
                
            }
            fclose($fh);
        }

        return $data;
    
    }
    public function conv_to_greece($str_orig,$str_tofindandreplace){
        // the function return string replaced greece letter
        //find in $str_orig the $str_tofindandreplace string and replace it by greece charakter
        
      
        $greece= array ("eps" => "&epsilon;");
        $checkTheCharInDB=FALSE;
        
        foreach ($greece as $pom_key => $pom_value){
            if($pom_key==$str_tofindandreplace){
                $checkTheCharInDB=TRUE;             
                break;
            }
        }
        
        if($checkTheCharInDB==TRUE){
        
            $position=strpos($str_orig,$str_tofindandreplace);
                if($position !== FALSE){        
                    $str_replaced=str_replace($str_tofindandreplace,$pom_value,$str_orig);
                }
        }
        return $str_replaced;
    }
}

//$cc = new CommonConcreteModel();
//$cc->read_concrete_props_data();


?>

