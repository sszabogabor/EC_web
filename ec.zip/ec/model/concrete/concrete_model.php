<?php     //concrete_model.php

class Concrete_model{


} //class

?>
