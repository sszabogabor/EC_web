<!--?php
include_once "view/index.php";  
?-->

<!DOCTYPE html>
<html>
    <head>
            <!--meta http-equiv="refresh" content="0; url=https://kisbo.000webhostapp.com/ec/view" /-->
            <meta http-equiv="refresh" content="0; url=view/index.php" />
    </head>

    <body>

    </body>
</html>