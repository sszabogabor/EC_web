<?php 

class MenuController{

    public function menu_build(){
    
        require_once "model/menu/menu_model.php";
        $menubuilder = new MenuBuilder();
        $menuarray=$menubuilder->readmenufromdir();
        

    }

}

?>
