<?php //bar_tension_controller.php

class LbrqdController{
    
    public function sanitizeString($var){
	$var=stripslashes($var);
	$var=strip_tags($var);
	$var=htmlentities($var);
	return $var;
    }
    
    private function getRidOfFRebarprops($var) {
        //get rid of fi at fi5.5 and fi 6.5 rebars
    
        if(strncmp($var,"f",1)){
                return $var ; 
        }
        else{
                return substr($var,2); 
        }
    
    }
   
    public function lbrqd(){
        
        
        $current_path = explode(DIRECTORY_SEPARATOR,__DIR__);
        $current_path_count_2less=count($current_path)-2;

        //build path to model folder
        $model_path=$current_path;
        array_splice($model_path,$current_path_count_2less,count($model_path),array("model","concrete","common_model.php"));
        $model_path_string = implode(DIRECTORY_SEPARATOR, $model_path);
        //load concrete model 
        include_once $model_path_string;
       
        $model = new CommonConcreteModel();
        //read rebars data
        $rebarprops = $model->read_rebar_data();
        $concreteprops=$model->read_concrete_props_data();
        
        //read data from $_POST
        if(isset($_POST['sd'])) $sd= floatval($this->sanitizeString($_POST['sd']));
        if(isset($_POST['fyk_sel'])) $fyk_sel= floatval($this->sanitizeString($_POST['fyk_sel']));
        if(isset($_POST['bond_co'])) $bond_co= floatval($this->sanitizeString($_POST['bond_co']));  
        
        //check the input and trigger the calculation
        if((isset($_POST['sd'])) and (isset($_POST['fyk_sel'])) and (isset($_POST['bond_co']))) {
        
            //check delected sd or input sd
            if ($sd=="0"){
                $sd=$fyk_sel/1.15;
            }            
            
            
            //prepare data for table
                       
            //TABLE FIRST ROW - CONCRETES
            $SubArray_concrete = array("Concrete");
            for ($i=2;$i<count($concreteprops);++$i){
                array_push($SubArray_concrete, 'C'.$concreteprops[$i][0].'/'.$concreteprops[$i][1]);
            }
            //TABLE SECOND ROW - fctk
            $SubArray_fctk = array("fctk 0.05 [MPa]");
            for ($i=2;$i<count($concreteprops);++$i){
                array_push($SubArray_fctk, $concreteprops[$i][4]);
            }

            //TABLE THIRD ROW - fbd fi<=32
            $SubArray_fdb_for_fi_under32 = array("fbd_under32 [MPa]");
            for ($i=2;$i<count($concreteprops);++$i){
                array_push($SubArray_fdb_for_fi_under32, round((2.25 *1 * $bond_co * $concreteprops[$i][4]/1.5),2));
            }
            //TABLE THIRD ROW - fbd fi=40
            $SubArray_fbd_for_fi40 = array("fbd_40 [MPa]");
            for ($i=2;$i<count($concreteprops);++$i){
                array_push($SubArray_fbd_for_fi40, round((2.25 *1 * $bond_co * $concreteprops[$i][4]/1.5 * ((132-40)/100)),2));
            }
            
            //TABLE THIRD ROW - fbd fi=50
            $SubArray_fbd_for_fi50 = array("fbd_50 [MPa]");
            for ($i=2;$i<count($concreteprops);++$i){
                array_push($SubArray_fbd_for_fi50, round((2.25 *1 * $bond_co * $concreteprops[$i][4]/1.5 * ((132-50)/100)),2));
            }
            
            //Basic anchorage length
            $SubArray_basic_anchorage_length = array("basic anchorage length");
            for ($i=0;$i<count($rebarprops);++$i){
                
                $temp_fi=floatval($this->getRidOfFRebarprops($rebarprops[$i][0]));
                
                //array to store dat for each reinforcement diameter 
                $SubArray_temp = array($temp_fi);
                
                //calcualte lbrqd for fi<= 32 and others
                if ($temp_fi<=32){
                    for ($j=2;$j<count($concreteprops);++$j){
                        array_push($SubArray_temp, round(($temp_fi/4)*($sd/(2.25 *1 * $bond_co * $concreteprops[$j][4]/1.5)),0));
                    }
                }
                elseif ($temp_fi>32){
                    for ($j=2;$j<count($concreteprops);++$j){
                        array_push($SubArray_temp, round(($temp_fi/4)*($sd/(2.25 *1 * $bond_co * $concreteprops[$j][4]/1.5* ((132-$temp_fi)/100))),0));
                    }
                    
                }
                array_push($SubArray_basic_anchorage_length, $SubArray_temp);
            }
            

            //define array to return
            $myarray = array($sd,$bond_co,$SubArray_concrete,$SubArray_fctk,$SubArray_fdb_for_fi_under32,$SubArray_basic_anchorage_length);
        }
        else {
        $myarray=FALSE;  
        }
        return $myarray;
    }
    

        
}

?>

