<?php //bar_tension_controller.php

class BarTensionController{
    
    public function sanitizeString($var){
	$var=stripslashes($var);
	$var=strip_tags($var);
	$var=htmlentities($var);
	return $var;
    }
   
    public function bar_tension(){
        
        
        $current_path = explode(DIRECTORY_SEPARATOR,__DIR__);
        $current_path_count_2less=count($current_path)-2;

        //build path to model folder
        $model_path=$current_path;
        array_splice($model_path,$current_path_count_2less,count($model_path),array("model","concrete","common_model.php"));
        $model_path_string = implode(DIRECTORY_SEPARATOR, $model_path);
        //load concrete model 
        include_once $model_path_string;
       
        $model = new CommonConcreteModel();
        //read rebars data
        $rebarprops = $model->read_rebar_data();
        
        if(isset($_POST['fyk'])) $fyk= floatval($this->sanitizeString($_POST['fyk']));
        if(isset($_POST['fi'])) $fi= ($this->sanitizeString ($_POST['fi']));
        if(isset($_POST['num_bar'])) $num_bar= floatval($this->sanitizeString ($_POST['num_bar']));
        if(isset($_POST['fyk_sel'])) $fyk_sel= floatval(($_POST['fyk_sel'])) ;


        if((isset($_POST['fyk'])) and (isset($_POST['fi'])) and (isset($_POST['num_bar'])) and (isset($_POST['fyk_sel']))){

            if ($fyk==0){
                    $fyk=$fyk_sel;
            }

            //find selected rebars data
            for ($i=0;$i<count($rebarprops);++$i){
                if ($fi==$rebarprops[$i][0]){
                    $ast=$rebarprops[$i][2];
                    break;
                }
            }
        $Rd=($fyk*$num_bar*floatval($ast)/1.15)/1000;    
        //define array to return
        $myarray = array("fyk"=>$fyk,"fi"=>$fi,"num_bar"=>$num_bar,"ast"=>$ast,"Rd"=>$Rd);
        }
        else {
        $myarray=FALSE;  
        }
        return $myarray;
    }
    

        
}

?>