<?php //min_max_reinforcement_areas_controller.php

class MinMaxReinfAreasController{
    
    public function sanitizeString($var){
	$var=stripslashes($var);
	$var=strip_tags($var);
	$var=htmlentities($var);
	return $var;
    }
   
    public function min_max_reinf_areas(){
        
        
        $current_path = explode(DIRECTORY_SEPARATOR,__DIR__);
        $current_path_count_2less=count($current_path)-2;

        //build path to model folder
        $model_path=$current_path;
        array_splice($model_path,$current_path_count_2less,count($model_path),array("model","concrete","common_model.php"));
        $model_path_string = implode(DIRECTORY_SEPARATOR, $model_path);
        //load concrete model 
        include_once $model_path_string;
       
        $model = new CommonConcreteModel();
        //read rebars data
        $rebarprops = $model->read_rebar_data();
        $concreteprops=$model->read_concrete_props_data();
        
        //read data from $_POST
        if(isset($_POST['Concrete'])) $Concrete= floatval($this->sanitizeString($_POST['Concrete']));
        if(isset($_POST['fyk'])) $fyk= floatval($this->sanitizeString($_POST['fyk']));
        if(isset($_POST['Bar'])) $Bar= floatval($this->sanitizeString($_POST['Bar']));  //diameter of bars
        if(isset($_POST['n'])) $n= floatval($this->sanitizeString($_POST['n']));    //number of bars
        if(isset($_POST['h'])) $h= floatval($this->sanitizeString($_POST['h']));
        if(isset($_POST['b'])) $b= floatval($this->sanitizeString($_POST['b']));
        if(isset($_POST['c'])) $c= floatval($this->sanitizeString($_POST['c']));

        if((isset($_POST['Concrete'])) and (isset($_POST['fyk'])) and (isset($_POST['Bar'])) and (isset($_POST['n'])) and (isset($_POST['h'])) and (isset($_POST['b'])) and (isset($_POST['c']))){

            
           //find selected rebars data
            for ($i=0;$i<count($rebarprops);++$i){
                if ($Bar==$rebarprops[$i][0]){
                    $ast1=$rebarprops[$i][2];
                    break;
                }
            }
                                           
           //find selected concrete data
           //$Concrete is the index of the selected conrete from dropbox starts with 0
           $fck=$concreteprops[$Concrete+2][0];
           $fctm=$concreteprops[$Concrete+2][3];
                    
            
            
        $d=$h-$c-$Bar/2;
	

        //reinforcement arae
        $ast=$ast1*$n;
        $astmin= max((0.26*$fctm*$b*$d/$fyk),(0.0013*$b*$d));
        $astmax=0.04*$b*$h;
           
 
        //define array to return
        $myarray = array("d"=>$d,"fck"=>$fck,"fctm"=>$fctm,"fyk"=>$fyk,"ast"=>round($ast,1),"astmin"=>round($astmin,1),"astmax"=>round($astmax,1));
        }
        else {
        $myarray=FALSE;  
        }
        return $myarray;
    }
    

        
}

?>

