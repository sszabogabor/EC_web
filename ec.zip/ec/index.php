<?php

include_once "system/startup.php";  
//startup::first(); 



?>
